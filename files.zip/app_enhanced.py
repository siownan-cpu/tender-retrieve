import os
from flask import Flask, render_template_string, send_file, request, jsonify
from dotenv import load_dotenv
from datetime import datetime

from collector.rss_client import fetch_feeds, load_feeds_config
from collector.html_fallback import fetch_today_opportunities
from processor.normalize import normalize_items
from exporter.excel import export_to_excel
from util.date_filter import filter_by_date

load_dotenv()

app = Flask(__name__)
cache_items = []

@app.route('/')
def index():
    feeds = load_feeds_config()
    return render_template_string(TEMPLATE, feeds=feeds, count=None, ts=None, download_ready=False)

@app.route('/fetch', methods=['POST'])
def fetch():
    selected_urls = request.form.getlist('feed_url')
    use_html = request.form.get('use_html') == '1'
    date_mode = request.form.get('date_mode', 'today')
    date_start = request.form.get('date_start')
    date_end = request.form.get('date_end')

    if date_start: 
        date_mode = 'custom'
    
    items = fetch_feeds(selected_urls=selected_urls)
    
    if use_html:
        items += fetch_today_opportunities()
        
    norm_items = normalize_items(items)
    filtered_items = filter_by_date(norm_items, mode=date_mode, start_date=date_start, end_date=date_end)
    
    global cache_items
    cache_items = filtered_items
    
    feeds = load_feeds_config()
    return render_template_string(TEMPLATE, feeds=feeds, count=len(cache_items), 
                                ts=datetime.now().strftime('%Y-%m-%d %H:%M'), 
                                date_mode=date_mode, download_ready=False)

@app.route('/export', methods=['POST'])
def export():
    output_dir = 'output'
    export_file = 'gebiz_daily.xlsx'
    os.makedirs(output_dir, exist_ok=True)
    path = os.path.join(output_dir, export_file)
    export_to_excel(cache_items, path)
    
    app.config['last_export'] = path
    feeds = load_feeds_config()
    return render_template_string(TEMPLATE, feeds=feeds, count=len(cache_items), 
                                ts=datetime.now().strftime('%Y-%m-%d %H:%M'), 
                                date_mode='exported', download_ready=True)

@app.route('/download')
def download():
    path = app.config.get('last_export')
    if not path:
        return 'No file', 404
    return send_file(path, as_attachment=True)

TEMPLATE = '''
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>GeBIZ RSS Feed Manager</title>
    <style>
        * { box-sizing: border-box; }
        body { 
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            padding: 0;
            margin: 0;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
        }
        
        .container {
            max-width: 1400px;
            margin: 0 auto;
            padding: 20px;
        }
        
        .header {
            background: white;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.2);
            margin-bottom: 30px;
        }
        
        h1 {
            margin: 0 0 10px 0;
            color: #1f2937;
            font-size: 32px;
            font-weight: 700;
        }
        
        .subtitle {
            color: #6b7280;
            font-size: 16px;
        }
        
        .main-content {
            display: grid;
            grid-template-columns: 1fr;
            gap: 20px;
        }
        
        .card {
            background: white;
            border-radius: 12px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
            overflow: hidden;
        }
        
        .card-header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 20px;
            font-weight: 600;
            font-size: 18px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .card-body {
            padding: 25px;
        }
        
        /* Feed Type Tabs */
        .feed-type-tabs {
            display: flex;
            gap: 10px;
            margin-bottom: 25px;
            padding: 5px;
            background: #f3f4f6;
            border-radius: 8px;
        }
        
        .feed-type-tab {
            flex: 1;
            padding: 12px 20px;
            background: white;
            border: 2px solid transparent;
            border-radius: 6px;
            cursor: pointer;
            text-align: center;
            font-weight: 600;
            transition: all 0.3s;
        }
        
        .feed-type-tab:hover {
            border-color: #667eea;
        }
        
        .feed-type-tab.active {
            background: #667eea;
            color: white;
            border-color: #667eea;
        }
        
        .feed-type-content {
            display: none;
        }
        
        .feed-type-content.active {
            display: block;
        }
        
        /* Category Selection */
        .category-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
            gap: 15px;
            margin-bottom: 20px;
        }
        
        .category-card {
            border: 2px solid #e5e7eb;
            border-radius: 8px;
            overflow: hidden;
            transition: all 0.3s;
        }
        
        .category-card:hover {
            border-color: #667eea;
            box-shadow: 0 4px 12px rgba(102, 126, 234, 0.2);
        }
        
        .category-header {
            background: #f9fafb;
            padding: 12px 15px;
            font-weight: 600;
            color: #1f2937;
            display: flex;
            justify-content: space-between;
            align-items: center;
            cursor: pointer;
            user-select: none;
        }
        
        .category-header:hover {
            background: #f3f4f6;
        }
        
        .category-count {
            background: #667eea;
            color: white;
            padding: 3px 10px;
            border-radius: 12px;
            font-size: 12px;
            font-weight: 600;
        }
        
        .category-body {
            padding: 15px;
            background: white;
            display: none;
        }
        
        .category-body.expanded {
            display: block;
        }
        
        .subcategory-item {
            display: flex;
            align-items: center;
            padding: 8px 0;
            border-bottom: 1px solid #f3f4f6;
        }
        
        .subcategory-item:last-child {
            border-bottom: none;
        }
        
        .subcategory-item input[type="checkbox"] {
            margin-right: 10px;
            width: 18px;
            height: 18px;
            cursor: pointer;
        }
        
        .subcategory-item label {
            flex: 1;
            cursor: pointer;
            font-size: 14px;
            color: #374151;
        }
        
        /* Controls */
        .controls {
            display: flex;
            gap: 15px;
            flex-wrap: wrap;
            margin-bottom: 20px;
        }
        
        .control-group {
            flex: 1;
            min-width: 200px;
        }
        
        .control-group label {
            display: block;
            font-weight: 600;
            margin-bottom: 5px;
            color: #374151;
            font-size: 14px;
        }
        
        .control-group select,
        .control-group input {
            width: 100%;
            padding: 10px;
            border: 2px solid #e5e7eb;
            border-radius: 6px;
            font-size: 14px;
            transition: border-color 0.3s;
        }
        
        .control-group select:focus,
        .control-group input:focus {
            outline: none;
            border-color: #667eea;
        }
        
        /* Buttons */
        .btn {
            padding: 12px 24px;
            border: none;
            border-radius: 6px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
            font-size: 14px;
        }
        
        .btn-primary {
            background: #667eea;
            color: white;
        }
        
        .btn-primary:hover {
            background: #5568d3;
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(102, 126, 234, 0.4);
        }
        
        .btn-secondary {
            background: #6b7280;
            color: white;
        }
        
        .btn-secondary:hover {
            background: #4b5563;
        }
        
        .btn-success {
            background: #10b981;
            color: white;
        }
        
        .btn-success:hover {
            background: #059669;
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(16, 185, 129, 0.4);
        }
        
        .btn-group {
            display: flex;
            gap: 10px;
            flex-wrap: wrap;
        }
        
        /* Stats */
        .stats-box {
            background: linear-gradient(135deg, #10b981 0%, #059669 100%);
            color: white;
            padding: 20px;
            border-radius: 8px;
            margin-top: 20px;
        }
        
        .stats-box h3 {
            margin: 0 0 10px 0;
            font-size: 18px;
        }
        
        .stats-box p {
            margin: 5px 0;
            font-size: 14px;
        }
        
        .stats-number {
            font-size: 36px;
            font-weight: 700;
            margin: 10px 0;
        }
        
        /* Utility */
        .checkbox-label {
            display: flex;
            align-items: center;
            gap: 8px;
            cursor: pointer;
            padding: 10px;
            background: #f9fafb;
            border-radius: 6px;
        }
        
        .checkbox-label input {
            width: 18px;
            height: 18px;
        }
        
        .arrow {
            transition: transform 0.3s;
            font-size: 12px;
        }
        
        .expanded .arrow {
            transform: rotate(90deg);
        }
        
        .section-divider {
            height: 2px;
            background: linear-gradient(90deg, transparent, #667eea, transparent);
            margin: 30px 0;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>🏛️ GeBIZ RSS Feed Manager</h1>
            <p class="subtitle">Select categories and fetch business opportunities or awards from GeBIZ RSS feeds</p>
        </div>
        
        <form method="post" action="/fetch">
            <!-- Date Filter Card -->
            <div class="card">
                <div class="card-header">
                    📅 Date Filter
                </div>
                <div class="card-body">
                    <div class="controls">
                        <div class="control-group">
                            <label>Quick Select</label>
                            <select name="date_mode" onchange="this.form.date_start.value='';this.form.date_end.value=''">
                                <option value="today">Today</option>
                                <option value="last_3_days">Last 3 Days (incl. Today)</option>
                                <option value="this_week">This Week (Since Monday)</option>
                                <option value="last_7_days">Last 7 Days</option>
                                <option value="custom">Custom Range</option>
                            </select>
                        </div>
                        <div class="control-group">
                            <label>Start Date</label>
                            <input type="date" name="date_start">
                        </div>
                        <div class="control-group">
                            <label>End Date</label>
                            <input type="date" name="date_end">
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="section-divider"></div>
            
            <!-- Feed Selection Card -->
            <div class="card">
                <div class="card-header">
                    <span>📋 Feed Selection</span>
                    <div class="btn-group">
                        <button type="button" class="btn btn-secondary" onclick="expandAll()">Expand All</button>
                        <button type="button" class="btn btn-secondary" onclick="collapseAll()">Collapse All</button>
                        <button type="button" class="btn btn-secondary" onclick="selectAll()">Select All</button>
                        <button type="button" class="btn btn-secondary" onclick="clearAll()">Clear All</button>
                    </div>
                </div>
                <div class="card-body">
                    <!-- Feed Type Tabs -->
                    <div class="feed-type-tabs">
                        <div class="feed-type-tab active" onclick="switchFeedType('opportunities')">
                            💼 Business Opportunities
                        </div>
                        <div class="feed-type-tab" onclick="switchFeedType('awards')">
                            🏆 Awards
                        </div>
                        <div class="feed-type-tab" onclick="switchFeedType('both')">
                            📊 Both
                        </div>
                    </div>
                    
                    <!-- Opportunities Content -->
                    <div id="opportunities-content" class="feed-type-content active">
                        <div class="category-grid">
                        {% for main, subs in feeds.items() %}
                            <div class="category-card">
                                <div class="category-header" onclick="toggleCategory(this)">
                                    <span>{{ main }}</span>
                                    <div style="display: flex; align-items: center; gap: 10px;">
                                        <span class="category-count">{{ subs|length }}</span>
                                        <span class="arrow">▶</span>
                                    </div>
                                </div>
                                <div class="category-body">
                                    {% for sub, types in subs.items() %}
                                        {% if types.get('bo') %}
                                        <div class="subcategory-item">
                                            <input type="checkbox" name="feed_url" value="{{ types['bo'] }}" 
                                                   id="bo_{{ loop.index0 }}_{{ loop.index }}" 
                                                   data-type="opportunities">
                                            <label for="bo_{{ loop.index0 }}_{{ loop.index }}">{{ sub }}</label>
                                        </div>
                                        {% endif %}
                                    {% endfor %}
                                </div>
                            </div>
                        {% endfor %}
                        </div>
                    </div>
                    
                    <!-- Awards Content -->
                    <div id="awards-content" class="feed-type-content">
                        <div class="category-grid">
                        {% for main, subs in feeds.items() %}
                            <div class="category-card">
                                <div class="category-header" onclick="toggleCategory(this)">
                                    <span>{{ main }}</span>
                                    <div style="display: flex; align-items: center; gap: 10px;">
                                        <span class="category-count">{{ subs|length }}</span>
                                        <span class="arrow">▶</span>
                                    </div>
                                </div>
                                <div class="category-body">
                                    {% for sub, types in subs.items() %}
                                        {% if types.get('awd') %}
                                        <div class="subcategory-item">
                                            <input type="checkbox" name="feed_url" value="{{ types['awd'] }}" 
                                                   id="awd_{{ loop.index0 }}_{{ loop.index }}" 
                                                   data-type="awards">
                                            <label for="awd_{{ loop.index0 }}_{{ loop.index }}">{{ sub }}</label>
                                        </div>
                                        {% endif %}
                                    {% endfor %}
                                </div>
                            </div>
                        {% endfor %}
                        </div>
                    </div>
                    
                    <!-- Both Content -->
                    <div id="both-content" class="feed-type-content">
                        <div class="category-grid">
                        {% for main, subs in feeds.items() %}
                            <div class="category-card">
                                <div class="category-header" onclick="toggleCategory(this)">
                                    <span>{{ main }}</span>
                                    <div style="display: flex; align-items: center; gap: 10px;">
                                        <span class="category-count">{{ subs|length }}</span>
                                        <span class="arrow">▶</span>
                                    </div>
                                </div>
                                <div class="category-body">
                                    {% for sub, types in subs.items() %}
                                        {% if types.get('bo') %}
                                        <div class="subcategory-item">
                                            <input type="checkbox" name="feed_url" value="{{ types['bo'] }}" 
                                                   id="both_bo_{{ loop.index0 }}_{{ loop.index }}" 
                                                   data-type="both">
                                            <label for="both_bo_{{ loop.index0 }}_{{ loop.index }}">{{ sub }} (Opportunity)</label>
                                        </div>
                                        {% endif %}
                                        {% if types.get('awd') %}
                                        <div class="subcategory-item">
                                            <input type="checkbox" name="feed_url" value="{{ types['awd'] }}" 
                                                   id="both_awd_{{ loop.index0 }}_{{ loop.index }}" 
                                                   data-type="both">
                                            <label for="both_awd_{{ loop.index0 }}_{{ loop.index }}">{{ sub }} (Award)</label>
                                        </div>
                                        {% endif %}
                                    {% endfor %}
                                </div>
                            </div>
                        {% endfor %}
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="section-divider"></div>
            
            <!-- Actions -->
            <div class="card">
                <div class="card-body">
                    <div style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 20px;">
                        <label class="checkbox-label">
                            <input type="checkbox" name="use_html" value="1">
                            <span>Include HTML Fallback (Today's Opportunities Only)</span>
                        </label>
                        <button type="submit" class="btn btn-primary">🚀 Fetch Selected Feeds</button>
                    </div>
                </div>
            </div>
        </form>
        
        <!-- Results -->
        {% if count is not none %}
        <div class="stats-box">
            <h3>✅ Fetch Complete</h3>
            <div class="stats-number">{{ count }}</div>
            <p>items captured at {{ ts }}</p>
            <p>Filter mode: <strong>{{ date_mode }}</strong></p>
            <form method="post" action="/export" style="margin-top: 15px;">
                <button type="submit" class="btn btn-success">📥 Export to Excel</button>
            </form>
        </div>
        {% endif %}
        
        {% if download_ready %}
        <div class="stats-box">
            <h3>🎉 Export Successful!</h3>
            <p><a href="/download" style="color: white; text-decoration: underline; font-weight: 600;">Download gebiz_daily.xlsx</a></p>
        </div>
        {% endif %}
    </div>
    
    <script>
        // Feed Type Switching
        function switchFeedType(type) {
            // Update tabs
            document.querySelectorAll('.feed-type-tab').forEach(tab => {
                tab.classList.remove('active');
            });
            event.target.classList.add('active');
            
            // Update content
            document.querySelectorAll('.feed-type-content').forEach(content => {
                content.classList.remove('active');
            });
            document.getElementById(type + '-content').classList.add('active');
        }
        
        // Category Toggle
        function toggleCategory(header) {
            const body = header.nextElementSibling;
            const arrow = header.querySelector('.arrow');
            body.classList.toggle('expanded');
            header.classList.toggle('expanded');
        }
        
        // Expand/Collapse All
        function expandAll() {
            document.querySelectorAll('.category-body').forEach(body => {
                body.classList.add('expanded');
            });
            document.querySelectorAll('.category-header').forEach(header => {
                header.classList.add('expanded');
            });
        }
        
        function collapseAll() {
            document.querySelectorAll('.category-body').forEach(body => {
                body.classList.remove('expanded');
            });
            document.querySelectorAll('.category-header').forEach(header => {
                header.classList.remove('expanded');
            });
        }
        
        // Select/Clear All
        function selectAll() {
            const activeContent = document.querySelector('.feed-type-content.active');
            activeContent.querySelectorAll('input[type="checkbox"]').forEach(cb => {
                cb.checked = true;
            });
        }
        
        function clearAll() {
            const activeContent = document.querySelector('.feed-type-content.active');
            activeContent.querySelectorAll('input[type="checkbox"]').forEach(cb => {
                cb.checked = false;
            });
        }
    </script>
</body>
</html>
'''

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=8000, debug=True)
