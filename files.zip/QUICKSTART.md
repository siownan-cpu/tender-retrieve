# 🚀 QUICK START GUIDE

## What You've Got

A modern, tabbed web interface for managing GeBIZ RSS feeds with:

✅ **3 Viewing Modes**:
   - Business Opportunities only
   - Awards only  
   - Both combined

✅ **12 Main Categories** with 95+ subcategories
✅ **Smart date filtering** (Today, Last 3 days, Last 7 days, Custom range)
✅ **One-click export** to Excel
✅ **Beautiful, responsive UI** with expand/collapse categories

---

## How to Run (3 Steps)

### 1. Install Dependencies
```bash
cd /path/to/gebiz-folder
pip install -r requirements.txt
```

### 2. Start the Application
```bash
python3 app_enhanced.py
```

Or simply:
```bash
./run.sh
```

### 3. Open Your Browser
Go to: **http://localhost:8000**

---

## How to Use

### 🎯 Basic Workflow

1. **Pick a date range** (top section)
   - Use presets like "Today" or "Last 7 Days"
   - Or select custom dates

2. **Choose a tab**:
   - 💼 **Business Opportunities** - Only opportunity feeds
   - 🏆 **Awards** - Only award feeds
   - 📊 **Both** - See everything

3. **Select categories**:
   - Click any category card to expand it
   - Check boxes for subcategories you want
   - Use "Select All" / "Clear All" for bulk actions

4. **Fetch**:
   - Click the big "🚀 Fetch Selected Feeds" button
   - Wait for results

5. **Export**:
   - Click "📥 Export to Excel"
   - Download your file

---

## 💡 Pro Tips

- **Start with "This Week"** to get a good amount of data
- **Use category expansion** to see what's available before selecting
- **The "Both" tab** shows opportunities and awards side-by-side
- **Export regularly** to build your tender database
- **Files save to** `output/gebiz_daily.xlsx`

---

## 📁 What's in the Package

```
gebiz-rss-manager/
├── app_enhanced.py       ← Main application (run this!)
├── requirements.txt      ← Python packages needed
├── run.sh               ← Quick start script
├── README_ENHANCED.md   ← Full documentation
├── config/
│   ├── feeds.yaml       ← Your 95 RSS feeds (auto-configured!)
│   └── filters.yaml     ← Keyword filters
├── collector/           ← RSS fetching modules
├── processor/           ← Data processing
├── exporter/            ← Excel export
└── util/                ← Helper functions
```

---

## 🆘 Troubleshooting

**Port 8000 already in use?**
- Stop other applications using that port
- Or edit `app_enhanced.py` line at the bottom to use different port

**No feeds showing?**
- The `config/feeds.yaml` file must exist
- It's already created from your Excel file!

**Installation errors?**
- Make sure you have Python 3.10+
- Use: `pip install --break-system-packages` on some systems

---

## 🎨 Interface Features

### Main Screen Sections:

1. **Header** - Title and description
2. **Date Filter Card** - Choose your date range
3. **Feed Selection Card** - The main interface with:
   - 3 tabs (Opportunities / Awards / Both)
   - Category cards (click to expand)
   - Subcategory checkboxes
   - Bulk action buttons
4. **Actions** - HTML fallback option and Fetch button
5. **Results** - Statistics and export button (after fetching)

### Color Coding:
- 🟣 Purple gradient = Primary actions
- 🟢 Green = Success / Export
- ⚪ White cards = Main content areas

---

## 📞 Need Help?

Check `README_ENHANCED.md` for:
- Detailed feature explanations
- Configuration options
- Technical details
- Full troubleshooting guide

---

**You're all set! Start the app and begin fetching GeBIZ feeds! 🎉**
