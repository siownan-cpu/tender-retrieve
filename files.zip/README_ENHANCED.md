# 🏛️ GeBIZ RSS Feed Manager

An enhanced web interface for selecting, fetching, and exporting GeBIZ RSS feeds with improved UI/UX.

## ✨ Features

### 📑 **Tabbed Interface**
- **Business Opportunities Tab**: Select RSS feeds for business opportunities
- **Awards Tab**: Select RSS feeds for awards
- **Both Tab**: Select from both opportunities and awards in one view

### 🎯 **Smart Category Selection**
- **12 Main Categories**: All GeBIZ procurement categories organized
- **95+ Subcategories**: Expandable categories with subcategory selection
- **Collapsible Cards**: Click to expand/collapse each main category
- **Bulk Actions**: Select All, Clear All, Expand All, Collapse All

### 📅 **Flexible Date Filtering**
- **Quick Presets**:
  - Today
  - Last 3 Days (including today)
  - This Week (since Monday)
  - Last 7 Days
  - Custom Date Range
- **Custom Range**: Select specific start and end dates

### 🎨 **Modern UI Design**
- Clean, professional gradient design
- Responsive layout that works on all screen sizes
- Visual feedback with hover effects
- Color-coded badges and counters
- Easy-to-read typography

### 📊 **Export Features**
- Export to Excel (`.xlsx` format)
- Compatible with Tender Comb format
- Download directly from browser
- Real-time statistics display

## 🚀 Quick Start

### Prerequisites
- Python 3.10 or higher
- pip package manager

### Installation

1. **Install Dependencies**:
   ```bash
   pip install -r requirements.txt
   ```

2. **Run the Application**:
   ```bash
   python3 app_enhanced.py
   ```
   
   Or use the convenience script:
   ```bash
   ./run.sh
   ```

3. **Open in Browser**:
   Navigate to: **http://localhost:8000**

## 📖 How to Use

### Step 1: Select Date Filter
1. Choose a quick preset (Today, Last 3 Days, etc.) OR
2. Select a custom date range using the date pickers

### Step 2: Choose Feed Type
Click one of the three tabs:
- **Business Opportunities**: Only opportunity feeds
- **Awards**: Only award feeds
- **Both**: See all available feeds

### Step 3: Select Categories
1. Click on any main category card to expand it
2. Check the boxes for subcategories you want to fetch
3. Use "Select All" / "Clear All" buttons for bulk selection
4. Use "Expand All" / "Collapse All" to manage the view

### Step 4: Fetch Feeds
1. Optionally check "Include HTML Fallback" for additional data
2. Click **"🚀 Fetch Selected Feeds"**
3. Wait for the results to appear

### Step 5: Export to Excel
1. Review the number of items captured
2. Click **"📥 Export to Excel"**
3. Click the download link to get your file

## 📁 Project Structure

```
gebiz-feed-manager/
├── app_enhanced.py          # Main Flask application
├── requirements.txt         # Python dependencies
├── .env                     # Configuration file
├── run.sh                  # Startup script
│
├── config/
│   ├── feeds.yaml          # Feed URLs (auto-generated from Excel)
│   └── filters.yaml        # Keyword filters
│
├── collector/
│   ├── rss_client.py       # RSS feed fetching
│   └── html_fallback.py    # HTML scraping (optional)
│
├── processor/
│   └── normalize.py        # Data normalization
│
├── exporter/
│   └── excel.py            # Excel export functionality
│
├── util/
│   └── date_filter.py      # Date filtering logic
│
└── output/
    └── gebiz_daily.xlsx    # Generated export files
```

## ⚙️ Configuration

### Environment Variables (`.env`)

```env
# Output directory for Excel files
OUTPUT_DIR=output

# Export filename
EXPORT_FILE=gebiz_daily.xlsx

# Optional: Path to existing Tender Comb workbook
# TENDER_COMB_PATH=/path/to/tender_comb.xlsx
```

### Feed Configuration (`config/feeds.yaml`)

The feed configuration is automatically generated from the Excel file `GeBIZ_RSS_Feeds_2.xlsx`. 

To regenerate:
```bash
python3 generate_feeds_from_excel.py
```

### Filter Configuration (`config/filters.yaml`)

Customize keywords, agencies, and categories to include/exclude:

```yaml
include_keywords:
  - hospital
  - healthcare
  - laboratory

exclude_keywords:
  - construction

agencies_preferred:
  - National Healthcare Group
  - NUH
```

## 📊 Excel Output Format

The exported Excel file includes the following columns:

| Column | Description |
|--------|-------------|
| Portal | Always "GeBIZ" |
| Tender Ref | Document/Tender Reference Number |
| Customer | Agency name |
| Tender Description | Title/Description of the tender |
| Date Detected | Date when item was fetched |
| Closing Date | Closing date from RSS feed |
| Closing Time | Closing time (if available) |
| Status | Status of tender (e.g., OPEN) |
| Deal ID | (Empty - for manual entry) |
| Remarks | Source URL/Link |

## 🔧 Troubleshooting

### Application Won't Start
- Ensure all dependencies are installed: `pip install -r requirements.txt`
- Check that port 8000 is available
- Verify Python version is 3.10+

### No Feeds Showing
- Ensure `config/feeds.yaml` exists
- Regenerate from Excel if needed

### No Results After Fetch
- Check your date filter settings
- Try expanding the date range
- Ensure you have selected at least one feed

### Excel Export Fails
- Check that `output/` directory is writable
- Ensure openpyxl is installed

## 🎯 Tips for Best Results

1. **Start Broad**: Begin with "This Week" or "Last 7 Days" to capture more items
2. **Use Tabs Effectively**: Switch between tabs to focus on opportunities or awards
3. **Organize by Category**: GeBIZ feeds are organized by procurement category - select relevant ones
4. **Regular Exports**: Export daily to maintain an up-to-date database
5. **Filter Keywords**: Use `filters.yaml` to automatically filter relevant items

## 📝 Technical Notes

### RSS Feed Structure
- Each subcategory has two feeds: Business Opportunity (`bo`) and Award (`awd`)
- Feeds are in XML format following RSS 2.0 specification
- Items include: title, description, link, publication date

### Compliance
- Follows GeBIZ Terms of Use and RSS Terms of Use
- RSS feeds are the recommended method by GeBIZ
- HTML fallback is optional and should be used responsibly

### Performance
- Fetches are done in parallel for faster results
- Date filtering is applied after fetching to ensure accuracy
- Excel exports use openpyxl for compatibility

## 🆘 Support

For issues or questions:
1. Check this README for common solutions
2. Review the configuration files
3. Check application logs in the terminal
4. Ensure all dependencies are up to date

## 📄 License

This tool is for internal use with GeBIZ public RSS feeds. Please comply with GeBIZ Terms of Use.

---

**Made with ❤️ for efficient GeBIZ tender monitoring**
